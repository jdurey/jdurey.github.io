window.COURSE_DATA = {
  "course_id": "FREECE_ACPE_DIV_USP800",
  "org_name": "PharmCon (freeCE)",
  "title": "PharmCon (freeCE) - Controlled Substance Diversion & USP <800> Hazardous Drug Safety CPE (Demo)",
  "credit_badge": "1.5 Contact Hours (0.15 CEU) · ACPE / ANCC Pharmacy & Nursing CPE SCORM 1.2",
  "source_digest": "Compiled from 21 CFR Part 1304/1305 (DEA CSOS & Form 106), ASHP Controlled Substances Diversion Prevention Guidelines, and USP General Chapter <800> Hazardous Drugs, modeled on PharmCon freeCE's catalog ('Preventing Controlled Substance Diversion in a Pharmacy' & 'Hazardous Drug Management for Pharmacists').",
  "ceu_profile": "accme_ancc_acpe",
  "mastery_score": 75,
  "pass_score": 75,
  "no_answer_leak_on_fail": true,
  "reveal_answers_on_fail": false,
  "objectives": [
    {
      "id": "OBJ_1",
      "text": "Audit automated dispensing cabinet variance logs and DEA Form 222/CSOS records to detect controlled-substance diversion."
    },
    {
      "id": "OBJ_2",
      "text": "Execute DEA Form 106 reporting timelines and perpetual inventory reconciliation for oxycodone (OxyContin) and buprenorphine-naloxone (Suboxone)."
    },
    {
      "id": "OBJ_3",
      "text": "Apply USP <800> containment primary engineering controls and closed-system drug-transfer device (CSTD) rules to NIOSH Table 1 antineoplastics."
    }
  ],
  "sections": [
    {
      "title": "1. DEA Perpetual Inventory Audits, ADC Variance Analytics & Form 106 Theft/Loss Reporting",
      "html": "<p>Under ASHP Diversion Prevention Guidelines and 21 CFR 1304.11, pharmacies must cross-reconcile CSOS/DEA Form 222 wholesaler invoices against CII perpetual inventory ledgers, Automated Dispensing Cabinet (ADC) override pulls, and witnessed waste logs for high-diversion agents such as oxycodone (OxyContin), hydromorphone, and buprenorphine-naloxone (Suboxone). Blind-count discrepancies, delayed waste co-signatures, or administration times charted after patient discharge require immediate audit escalation.</p><p>Under 21 CFR 1301.76(b) as amended by the DEA Final Rule, registrants must notify the local DEA Field Division Office in writing within 1 business day of discovering a theft or significant loss of controlled substances and submit an electronic DEA Form 106 within 45 calendar days (while maintaining naloxone (Narcan) emergency reversal readiness in clinical areas).</p>"
    },
    {
      "title": "2. USP General Chapter <800> Hazardous Drug Containment, Negative Pressure & CSTD Mandates",
      "html": "<p>USP &lt;800&gt; requires facilities handling NIOSH Table 1 antineoplastic hazardous drugs to store unpackaged vials (other than final unit-dose oral solids if exempted by Assessment of Risk) in an externally vented negative-pressure room (-0.01 to -0.03 inches water column) with at least 12 air changes per hour (ACPH). Sterile hazardous compounding requires an ISO Class 5 Containment Primary Engineering Control inside an ISO Class 7 negative-pressure buffer room (30 ACPH).</p><p>Note the critical USP &lt;800&gt; distinction between compounding and nursing administration: Closed-System Drug-Transfer Devices (CSTDs) are recommended during sterile hazardous drug compounding, whereas CSTDs are mandatory during antineoplastic hazardous drug administration whenever the dosage form allows, paired with two pairs of ASTM D6978 chemotherapy-tested gloves.</p>"
    }
  ],
  "quiz": [
    {
      "objective_id": "OBJ_1",
      "question": "During a monthly diversion surveillance audit, which Automated Dispensing Cabinet (ADC) pattern on a surgical unit requires immediate chart-to-administration forensic investigation?",
      "options": [
        "A clinician whose oxycodone (OxyContin) waste transactions exceed peer Z-score by +3.4 SD with repeated unwitnessed delayed waste entries",
        "Barcode-scanned scheduled administration of pantoprazole (Protonix) matching verified MAR timestamps",
        "Closed-loop CSOS electronic receipt matching exact wholesaler NDC lot counts on CII delivery",
        "Documented blind perpetual count showing zero variance across three consecutive shift handoffs"
      ],
      "explanations": [
        "High statistical outlier waste paired with delayed or solo waste entries is a hallmark diversion signature under ASHP guidelines.",
        "Non-controlled proton pump inhibitor barcode administration with exact MAR alignment reflects compliant practice.",
        "Exact CSOS-to-invoice reconciliation confirms intact chain of custody.",
        "Zero blind-count variance across shifts indicates compliant perpetual inventory control."
      ],
      "correct": 1,
      "overall": "ASHP diversion surveillance flags clinicians with >2.5 to 3.0 SD waste/override outliers and delayed waste documentation for immediate chart-to-MAR audit."
    },
    {
      "objective_id": "OBJ_2",
      "question": "A pharmacy manager confirms a significant unexplained loss of Schedule II oxycodone (OxyContin) and Schedule III buprenorphine-naloxone (Suboxone) tablets on Monday morning. Under current 21 CFR 1301.76(b) DEA rules, what reporting deadlines apply?",
      "options": [
        "Notify the DEA Field Division in writing within 1 business day of discovery and submit electronic DEA Form 106 within 45 calendar days",
        "Wait until the biennial controlled-substance inventory date before filing a paper DEA Form 106",
        "Report only Schedule II losses within 90 days because Schedule III losses are exempt from DEA Form 106",
        "Destroy remaining stock via DEA Form 41 instead of reporting a theft or significant loss"
      ],
      "explanations": [
        "21 CFR 1301.76(b) mandates written initial notification within 1 business day of discovery and electronic DEA Form 106 submission within 45 calendar days.",
        "Delaying until biennial inventory violates the 1-business-day initial notification and 45-day Form 106 deadlines.",
        "21 CFR 1301.76(b) covers thefts and significant losses across Schedules II through V, not solely Schedule II.",
        "DEA Form 41 documents intentional registrant destruction of damaged/expired stock, never unaccounted theft or loss."
      ],
      "correct": 1,
      "overall": "DEA regulations require 1-business-day written field notification upon discovery and electronic DEA Form 106 submission within 45 calendar days."
    },
    {
      "objective_id": "OBJ_3",
      "question": "Under USP General Chapter <800>, how do Closed-System Drug-Transfer Device (CSTD) and glove requirements apply to NIOSH Table 1 antineoplastic IV infusions?",
      "options": [
        "CSTDs are optional during IV administration if a single pair of standard vinyl exam gloves is worn",
        "CSTDs are recommended during sterile compounding and mandatory during antineoplastic administration when the dosage form allows, paired with double ASTM D6978 gloves",
        "CSTDs replace the need for an externally vented negative-pressure C-SEC room during sterile hazardous compounding",
        "ASTM D6978 gloves are required only when unpacking outer shipping cartons in positive-pressure storage"
      ],
      "explanations": [
        "Vinyl exam gloves are not chemotherapy-rated, and USP <800> mandates CSTDs during antineoplastic administration when dosage form permits.",
        "USP <800> Section 5.4 recommends CSTDs for compounding, mandates CSTDs for antineoplastic administration when feasible, and requires double ASTM D6978 gloves.",
        "CSTDs are supplemental controls and never substitute for required ISO-classified negative-pressure engineering controls.",
        "Antineoplastic compounding and administration both require double ASTM D6978 chemotherapy-tested gloves, and HD storage must be negative pressure."
      ],
      "correct": 2,
      "overall": "USP <800> distinguishes recommended CSTD use in compounding from mandatory CSTD use during antineoplastic administration alongside double ASTM D6978 gloves."
    },
    {
      "objective_id": "OBJ_3",
      "question": "Which environmental pressure differential and air-exchange specification satisfies USP <800> for a sterile hazardous drug ISO Class 7 negative-pressure buffer room?",
      "options": [
        "Positive pressure (+0.02 to +0.05 inches water column) recirculated into the main pharmacy HVAC return",
        "Negative pressure between -0.01 and -0.03 inches water column relative to adjacent spaces, externally vented, with at least 30 air changes per hour",
        "Neutral 0.00 pressure differential with 4 air changes per hour and internal HEPA recirculation only",
        "Unmonitored ambient room pressure provided compounding finishes in under 30 minutes"
      ],
      "explanations": [
        "Positive pressure pushes hazardous drug aerosols outward into non-containment zones and violates USP <800>.",
        "USP <800> mandates external venting, -0.01 to -0.03 inches WC negative pressure, and >= 30 ACPH for an ISO Class 7 sterile HD buffer room.",
        "Neutral pressure and 4 ACPH fail containment and particulate clearance standards.",
        "Continuous pressure monitoring and negative containment apply regardless of compounding duration."
      ],
      "correct": 2,
      "overall": "Sterile HD ISO Class 7 buffer rooms require external venting, -0.01 to -0.03 inches WC negative pressure, and >= 30 ACPH."
    }
  ],
  "front_matter_rendered_before_content": true,
  "front_matter": {
    "faculty_credentials": "Lead Author: Elena Vance, PharmD, BCPS; Compliance Reviewer: M. Chen, RPh",
    "financial_disclosures_and_mitigation": "All planners, authors, and peer reviewers report zero financial relationships with ineligible healthcare companies within the prior 24 months.",
    "commercial_support_statement": "This continuing pharmacy education activity received zero commercial or industry financial support.",
    "release_date": "2026-10-01",
    "expiration_date": "2029-10-01"
  },
  "evaluation_required_before_certificate": true,
  "post_evaluation": {
    "evaluation_required_before_certificate": true,
    "questions": [
      {
        "category": "objective_achievement",
        "question": "Rate the extent to which this continuing education activity achieved each stated learning objective."
      },
      {
        "category": "commercial_bias",
        "question": "Was this clinical continuing education activity balanced, evidence-based, and free of commercial bias?"
      }
    ]
  }
};
