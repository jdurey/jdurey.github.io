// Deterministic ADL SCORM 1.2 Runtime Wrapper (Zero External Dependencies)
(function(win){
  function findAPI(w){
    var tries = 0;
    while (w && !w.API && w.parent && w.parent !== w && tries < 10) {
      tries++;
      w = w.parent;
    }
    return (w && w.API) ? w.API : null;
  }
  var api = findAPI(win) || (win.opener ? findAPI(win.opener) : null);
  var startEpoch = Date.now();
  var state = {
    "cmi.core.lesson_status": "incomplete",
    "cmi.core.score.raw": "0",
    "cmi.core.score.min": "0",
    "cmi.core.score.max": "100",
    "cmi.core.lesson_location": "step_0",
    "cmi.core.session_time": "0000:00:00.00"
  };
  function fmtScormTime(ms){
    var sec = Math.max(0, Math.floor(ms / 1000));
    var hh = String(Math.floor(sec / 3600)).padStart(4, "0");
    var mm = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
    var ss = String(sec % 60).padStart(2, "0");
    return hh + ":" + mm + ":" + ss + ".00";
  }
  win.Scorm12 = {
    connected: !!api,
    state: state,
    init: function(){
      if (api && api.LMSInitialize) api.LMSInitialize("");
      this.set("cmi.core.lesson_status", "incomplete");
      this.set("cmi.core.lesson_location", "step_0");
      this.commit();
    },
    set: function(k, v){
      state[k] = String(v);
      if (api && api.LMSSetValue) api.LMSSetValue(k, String(v));
      this.renderBar();
    },
    bookmark: function(loc){
      this.set("cmi.core.lesson_location", loc);
      this.set("cmi.core.session_time", fmtScormTime(Date.now() - startEpoch));
      this.commit();
    },
    recordScore: function(pct, mastery, allowComplete){
      var rounded = Math.round(pct);
      this.set("cmi.core.score.min", "0");
      this.set("cmi.core.score.max", "100");
      this.set("cmi.core.score.raw", String(rounded));
      this.set("cmi.core.session_time", fmtScormTime(Date.now() - startEpoch));
      if (pct >= mastery && allowComplete !== false) {
        this.set("cmi.core.lesson_status", "passed");
      } else if (pct >= mastery && allowComplete === false) {
        this.set("cmi.core.lesson_status", "incomplete");
      } else {
        this.set("cmi.core.lesson_status", "failed");
      }
      this.commit();
    },
    finish: function(){
      this.set("cmi.core.session_time", fmtScormTime(Date.now() - startEpoch));
      if (api && api.LMSCommit) api.LMSCommit("");
      if (api && api.LMSFinish) api.LMSFinish("");
    },
    commit: function(){
      if (api && api.LMSCommit) api.LMSCommit("");
      this.renderBar();
    },
    renderBar: function(){
      var connEl = document.getElementById("scorm-conn");
      var cmiEl = document.getElementById("scorm-cmi");
      if (connEl) {
        connEl.textContent = api
          ? "SCORM 1.2 Runtime: Connected to Host LMS API"
          : "SCORM 1.2 Runtime: Standalone Preview Mode (LMS API Simulated)";
      }
      if (cmiEl) {
        cmiEl.textContent =
          'status="' + state["cmi.core.lesson_status"] + '" | score="' + state["cmi.core.score.raw"] +
          '" | loc="' + state["cmi.core.lesson_location"] + '" | time="' + state["cmi.core.session_time"] + '"';
      }
    }
  };
})(window);
