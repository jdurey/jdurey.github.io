window.COURSE_DATA = {
  "course_id": "SEU_ASCE722_SHEARLUGS",
  "org_name": "SE University",
  "title": "SE University - ASCE 7-22 Wind/Tornado Loads & ACI 318-19 Shear Lug Connections PDH (Demo)",
  "credit_badge": "1.0 PDH Credit · NCEES CPC / Structural Engineering Self-Study SCORM 1.2",
  "source_digest": "Compiled from ASCE/SEI 7-22 Chapters 26-32 (Updated Wind Velocity Pressure Profile & New Chapter 32 Tornado Loads) and ACI 318-19 Section 17.11 / AISC Design Guide 1 (Concrete Bearing & Breakout for Welded Base-Plate Shear Lugs), modeled on SE University's catalog ('Wind Loads in ASCE 7-22' & 'Shear Lugs: Myths, Mysteries, and Misunderstandings when Dealing with Concrete Connections').",
  "ceu_profile": "cle_pdh",
  "mastery_score": 75,
  "pass_score": 75,
  "no_answer_leak_on_fail": true,
  "reveal_answers_on_fail": false,
  "objectives": [
    {
      "id": "OBJ_1",
      "text": "Determine Risk Category III and IV tornado-load applicability and updated Kz velocity pressure exposure coefficients under ASCE 7-22 Chapters 26 through 32."
    },
    {
      "id": "OBJ_2",
      "text": "Calculate concrete bearing strength and concrete breakout capacity for welded steel base-plate shear lugs under ACI 318-19 Section 17.11."
    },
    {
      "id": "OBJ_3",
      "text": "Verify load-distribution compatibility so cast-in anchor bolts and welded shear lugs are not erroneously summed directly in column base shear transfer."
    }
  ],
  "sections": [
    {
      "title": "1. ASCE 7-22 Wind Load Revisions: Updated Kz Profiles, Elevated-Structure Rules & Chapter 32 Tornado Loads",
      "html": "<p>ASCE/SEI 7-22 introduced historic updates across Chapters 26 through 32. First, Chapter 32 establishes mandatory Tornado Load provisions solely for Risk Category III and Risk Category IV buildings and other structures located inside the Tornado-Prone Region (covering most of the US east of the Continental Divide), evaluated as an envelope alongside Chapter 27-30 synoptic/hurricane wind loads using tornado-specific internal pressure and directionality modifiers.</p><p>Second, ASCE 7-22 updated atmospheric boundary-layer gradient heights (zg) and empirical terrain exponents (updated velocity pressure coefficient Kz tables across Exposure B and C), eliminated the simplified Envelope Part 2 enclosed-simple-diaphragm shortcut tables in favor of unified Main Wind Force Resisting System (MWFRS) and Components &amp; Cladding (C&amp;C) procedures, and added explicit aerodynamic provisions for elevated coastal/floodplain structures.</p>"
    },
    {
      "title": "2. ACI 318-19 Section 17.11 & AISC Design Guide 1: Base-Plate Shear Lug Bearing, Breakout & Stiffness Compatibility",
      "html": "<p>ACI 318-19 added explicit code provisions in Section 17.11 for steel shear lugs welded to column base plates and embedded into concrete pedestals/grout pockets. Engineers must check both concrete bearing on the effective shear lug projected area (excluding the grout bed thickness!) and concrete shear breakout (Vcbg) toward free pedestal edges, plus cantilever bending of the shear lug plate and double-fillet or CJP weld demand at the base-plate interface.</p><p>A pervasive connection myth is summing anchor-rod shear strength plus shear-lug capacity plus base-plate friction simultaneously. Because oversized base-plate holes (per AISC Table 14-2) require substantial horizontal slip before anchor rods bear (unless plate washers are welded), whereas a grouted shear lug engages immediately at stiff small deformations, engineers design the shear lug (or friction + shear lug per ACI 318-19 17.11.1.1.2 constraints) to carry the full factored shear without combining anchor-bolt shear.</p>"
    }
  ],
  "quiz": [
    {
      "objective_id": "OBJ_1",
      "question": "Under ASCE/SEI 7-22 Chapter 32, which project requires a mandatory Tornado Load evaluation in addition to Chapters 27-30 wind design?",
      "options": [
        "A Risk Category II suburban warehouse located in Oklahoma City",
        "A Risk Category IV acute-care hospital or Risk Category III public high school located within the ASCE 7-22 Tornado-Prone Region",
        "A Risk Category I agricultural storage barn in Kansas",
        "Any single-family detached residence nationwide regardless of Risk Category"
      ],
      "explanations": [
        "ASCE 7-22 Chapter 32 (Section 32.1.1) applies strictly to Risk Category III and IV structures in the Tornado-Prone Region, not Risk Category II.",
        "Section 32.1.1 mandates Chapter 32 tornado load determination for Risk Category III and IV buildings located in the Tornado-Prone Region.",
        "Risk Category I structures are excluded from Chapter 32 tornado design.",
        "Residential Risk Category II structures are outside the scope of mandatory ASCE 7-22 Chapter 32 provisions."
      ],
      "correct": 2,
      "overall": "ASCE 7-22 Chapter 32 mandates tornado-load checks specifically for Risk Category III and IV buildings located within the Tornado-Prone Region."
    },
    {
      "objective_id": "OBJ_2",
      "question": "When calculating the effective concrete bearing area (Abrg) of a welded steel shear lug beneath a 2-inch non-shrink grout pad under ACI 318-19 Section 17.11.2, which portion of the lug depth contributes to bearing resistance?",
      "options": [
        "The entire total depth of the shear lug measured from the underside of the steel base plate, including the 2-inch grout layer",
        "Only the embedded portion of the shear lug projecting into the structural concrete foundation below the grout bed (excluding grout thickness)",
        "Twice the base-plate plan area regardless of lug embedment depth",
        "Zero concrete bearing check is required if anchor rods are ASTM F1554 Grade 55"
      ],
      "explanations": [
        "ACI 318-19 Section 17.11.2 excludes the grout bed thickness from effective bearing area while still accounting for the grout lever arm in lug bending.",
        "Effective bearing area Abrg includes only the projected lug area bearing directly against structural concrete below the grout pad, though grout thickness increases bending moment on the lug-to-base-plate weld.",
        "Base-plate plan area governs vertical axial bearing, not horizontal shear-lug face bearing.",
        "Anchor rod grade does not waive ACI 318-19 Section 17.11 bearing and concrete breakout checks on a shear lug."
      ],
      "correct": 2,
      "overall": "ACI 318-19 excludes grout thickness from effective concrete bearing area while retaining the full lever arm across the grout layer for lug bending design."
    },
    {
      "objective_id": "OBJ_3",
      "question": "Why do ACI 318-19 Section 17.11.1 and AISC Design Guide 1 prohibit directly adding standard-oversized-hole anchor-rod shear strength to welded shear-lug shear capacity at a column base?",
      "options": [
        "Deformation incompatibility: the stiff grouted shear lug engages and triggers concrete breakout before the base plate slips far enough across oversized holes to engage unweighted anchor rods",
        "Steel anchor rods dissolve chemically when placed within 12 inches of a welded shear lug",
        "ASCE 7-22 bans anchor rods on any column subjected to wind uplift",
        "Welded shear lugs resist only tension uplift and carry zero horizontal shear"
      ],
      "explanations": [
        "Base-plate holes per AISC Table 14-2 are significantly oversized; concrete breakout at the stiff shear lug occurs at tiny displacements long before anchor rods bear in shear.",
        "No chemical incompatibility exists between carbon/alloy steel anchor rods and structural steel shear lugs.",
        "Anchor rods remain essential for uplift tension and erection stability.",
        "Shear lugs specifically transfer horizontal base shear into the concrete pedestal, never tension uplift."
      ],
      "correct": 1,
      "overall": "Stiffness/slip incompatibility prevents simultaneous peak mobilization of grouted shear lugs and anchor rods in oversized base-plate holes."
    },
    {
      "objective_id": "OBJ_2",
      "question": "A shear lug transfers horizontal shear toward a nearby free edge of a concrete pier. In addition to lug bearing, plate bending, and base-plate weld sizing, which concrete failure limit state must be checked under ACI 318-19 Section 17.11.3?",
      "options": [
        "Concrete shear breakout (Vcbg) of the pier edge in front of the shear lug, accounting for axial anchor tension effects where applicable",
        "Timber grain crushing perpendicular to load",
        "Soil liquefaction only, omitting pedestal concrete checks",
        "Punching shear of an elevated post-tensioned roof slab"
      ],
      "explanations": [
        "ACI 318-19 Section 17.11.3 requires checking concrete breakout strength in shear toward free edges (and checking whether anchor tension cracks the breakout prism).",
        "Timber bearing provisions do not apply to reinforced concrete pedestals.",
        "Geotechnical checks never replace structural concrete pedestal breakout design.",
        "Two-way slab punching shear is distinct from pedestal edge shear breakout in front of a shear lug."
      ],
      "correct": 1,
      "overall": "Pedestal edge proximity often governs shear-lug capacity via concrete shear breakout under ACI 318-19 Section 17.11.3."
    }
  ],
  "verified_seat_minutes": 60.0,
  "tracks_session_time": true,
  "tracks_lesson_location": true,
  "anti_skip_gating": true,
  "randomize_options_on_retry": true,
  "attention_checkpoints": [
    {
      "minute_mark": 18,
      "prompt": "NCEES PDH Checkpoint 1 (18:00): Confirm active P.E. review of ASCE 7-22 Chapters 26-32."
    },
    {
      "minute_mark": 36,
      "prompt": "NCEES PDH Checkpoint 2 (36:00): Confirm active P.E. review of ACI 318-19 Chapter 17 Shear Lugs."
    },
    {
      "minute_mark": 54,
      "prompt": "NCEES PDH Checkpoint 3 (54:00): Confirm active seat-time completion before Final PDH Quiz."
    }
  ]
};
