window.COURSE_DATA = {
  "course_id": "CLEARLY_IFS_SUICIDE_AUTISM",
  "org_name": "Clearly Clinical",
  "title": "Clearly Clinical - IFS Therapist Reactivity in Suicide Risk & Neurodiversity-Affirming Care CE (Demo)",
  "credit_badge": "1.0 CE Credit · APA / ASWB ACE / NBCC Behavioral Health SCORM 1.2",
  "source_digest": "Compiled from APA Ethical Principles, C-SSRS / Stanley-Brown Safety Planning standards, and Internal Family Systems (IFS) neurodiversity-affirming clinical practice, modeled on Clearly Clinical's catalog ('When Suicide Comes Up: Regulating Therapist Reactivity in High-Stakes Sessions with IFS (Ep. 264)' & 'Autism Through an IFS Lens: Reducing Uncertainty and Building Self-Compassion').",
  "ceu_profile": "accme_ancc_acpe",
  "mastery_score": 75,
  "pass_score": 75,
  "no_answer_leak_on_fail": true,
  "reveal_answers_on_fail": false,
  "objectives": [
    {
      "id": "OBJ_1",
      "text": "Differentiate clinician manager-part countertransference reactivity from Self-led collaborative suicide risk formulation during acute ideation."
    },
    {
      "id": "OBJ_2",
      "text": "Document structured C-SSRS lethality triage, lethal-means counseling, and Stanley-Brown safety planning alongside pharmacotherapy coordination."
    },
    {
      "id": "OBJ_3",
      "text": "Modify Internal Family Systems language and sensory-predictability scaffolds for autistic clients experiencing alexithymia or masking fatigue."
    }
  ],
  "sections": [
    {
      "title": "1. Regulating Therapist Manager-Part Reactivity & Executing Evidence-Based Suicide Risk Triage",
      "html": "<p>When a client discloses suicidal ideation in session, clinician protective &#x27;manager&#x27; parts frequently surge with urgency, interrogation, or premature hospitalization threats that inadvertently shame the client and shut down honest disclosure. Within an Internal Family Systems (IFS) informed clinical frame, regulating clinician somatic reactivity restores grounded curiosity while still executing every mandatory legal and ethical standard-of-care suicide assessment step.</p><p>Specifically, clinicians pair non-shaming validation of the suicidal firefighter part&#x27;s pain-relief function with structured Columbia-Suicide Severity Rating Scale (C-SSRS) intent/plan/means assessment, collaborative Stanley-Brown 6-step safety planning, specific lethal-means restriction counseling, and documented coordination with the prescribing psychiatrist when selective serotonin reuptake inhibitors such as sertraline (Zoloft) or escitalopram (Lexapro) were recently initiated or adjusted.</p>"
    },
    {
      "title": "2. Neurodiversity-Affirming IFS Adaptations: Literal Prompts, Interoceptive Pacing & Unmasking Safety",
      "html": "<p>Standard open-ended IFS prompts (&#x27;Where do you notice that part in or around your body?&#x27;) can create high cognitive uncertainty for autistic adults with co-occurring alexithymia or interoceptive differences. Neurodiversity-affirming IFS replaces vague metaphors with concrete menus, visual parts-mapping cards, explicit session agendas, and sensory-safe pacing.</p><p>Critically, autistic sensory overload, monotropism, and stimming are neurodevelopmental traits rather than trauma &#x27;parts&#x27; to be unburdened; clinical work focuses instead on reducing camouflaging/masking exhaustion and softening internalized shame-driven critic parts.</p>"
    }
  ],
  "quiz": [
    {
      "objective_id": "OBJ_1",
      "question": "A client states, 'Part of me keeps thinking everyone would be relieved if I went to sleep and never woke up.' Which therapist response integrates Self-led IFS regulation with ethical suicide-risk assessment?",
      "options": [
        "Acknowledge how exhausted that part feels without panic, then conduct a transparent C-SSRS inquiry into active intent, plan, and access to lethal means",
        "Immediately terminate therapeutic dialogue and call emergency transport before asking whether the client has suicidal intent or a plan",
        "Explore childhood attachment metaphors exclusively and omit direct lethality questions to avoid triggering clinician anxiety",
        "Require the client to sign a standalone 'no-suicide contract' in lieu of a collaborative safety plan"
      ],
      "explanations": [
        "Grounded curiosity keeps disclosure open while fulfilling the non-negotiable clinical duty to assess intent, plan, and lethal means.",
        "Automatic involuntary transport for passive ideation without lethality assessment escalates trauma and erodes therapeutic trust.",
        "Omitting structured lethality triage when suicidal ideation is disclosed breaches behavioral health standard of care.",
        "Empirical literature demonstrates standalone 'no-suicide contracts' lack protective efficacy and never replace Stanley-Brown safety planning."
      ],
      "correct": 1,
      "overall": "Self-led regulation prevents panic-driven interrogation while ensuring complete C-SSRS lethality triage and collaborative safety planning."
    },
    {
      "objective_id": "OBJ_2",
      "question": "When documenting an outpatient high-stakes session involving passive suicidal ideation without imminent intent, plus a recent primary-care dose change of sertraline (Zoloft), which progress-note elements satisfy utilization and risk-management standards?",
      "options": [
        "Objective C-SSRS risk/protective factors, completed Stanley-Brown safety plan steps, lethal-means counseling, crisis line resources (988), and ROI-consented prescriber coordination",
        "A brief one-line entry stating 'Client safe at departure; will reassess next Tuesday'",
        "Verbatim process notes of unrelated family dreams with zero mention of lethal-means inquiry",
        "Instructing the client to abruptly discontinue sertraline (Zoloft) without contacting the prescribing physician"
      ],
      "explanations": [
        "Comprehensive risk-protective formulation, concrete safety plan documentation, lethal-means restriction, and prescriber coordination establish defensible care.",
        "Conclusory 'client safe' notes without objective C-SSRS findings or safety-plan steps fail clinical and legal documentation standards.",
        "Omitting lethal-means assessment and protective factor documentation leaves critical clinical risk unaddressed.",
        "Non-prescribing psychotherapists must never direct medication discontinuation; they coordinate via authorized prescriber communication."
      ],
      "correct": 1,
      "overall": "Defensible suicide-risk documentation captures specific C-SSRS findings, lethal-means counseling, collaborative safety steps, and prescriber coordination."
    },
    {
      "objective_id": "OBJ_3",
      "question": "An autistic client freezes when asked, 'Go inside and tell me what sensation shows up in your chest.' Which neurodiversity-affirming IFS adaptation best reduces uncertainty?",
      "options": [
        "Interpret the freeze as treatment resistance from a defiant protector part and repeat the somatic prompt louder",
        "Offer concrete externalized options such as visual cards, written descriptors, or cognitive thoughts/action urges instead of requiring interoceptive metaphors",
        "Attempt to 'unburden' the client's lifelong autistic sensory sensitivities and hand-flapping stims as trauma exiles",
        "Abandon collaborative goal-setting and switch to unannounced exposure exercises without consent"
      ],
      "explanations": [
        "Mislabeling alexithymia or processing latency as defiance compounds clinical shame and misattunement.",
        "Externalized visual or cognitive-behavioral anchors accommodate interoceptive differences and reduce ambiguous-prompt overwhelm.",
        "Neurodevelopmental traits and regulatory stims are core neurology to affirm, never pathology or 'parts' to eliminate.",
        "Unpredictable, non-consensual interventions heighten autonomic threat and violate affirming practice."
      ],
      "correct": 2,
      "overall": "Concrete choices, visual mapping, and non-interoceptive entry points make parts work accessible for autistic clients with alexithymia."
    },
    {
      "objective_id": "OBJ_3",
      "question": "In neurodiversity-affirming IFS therapy, how should a clinician conceptualize an autistic adult's chronic social masking part versus sensory meltdowns?",
      "options": [
        "Treat chronic masking as an adaptive manager role developed to navigate social rejection, while addressing sensory meltdowns through environmental load reduction rather than parts unburdening",
        "Demand immediate 100 percent unmasking across unsafe workplaces without assessing real-world safety consequences",
        "Classify sensory meltdowns as manipulative behavior warranting extinction contingencies",
        "Frame autism itself as a dissociative subpersonality caused by early parenting"
      ],
      "explanations": [
        "Masking functions as an understandable protective adaptation with high energy cost, whereas sensory meltdowns reflect neurological overload requiring sensory accommodations.",
        "Forced unmasking in unsupportive environments ignores real discrimination risks and violates IFS respect for protective pacing.",
        "Sensory meltdowns are involuntary autonomic/sensory overwhelm responses, never operant manipulation.",
        "Framing autism as psychogenic or parenting-induced is scientifically discredited and harmful."
      ],
      "correct": 1,
      "overall": "Affirming clinicians honor the protective history of masking parts while supporting pacing, consent, and sensory accommodations."
    }
  ],
  "front_matter_rendered_before_content": true,
  "front_matter": {
    "faculty_credentials": "Clinical Faculty: Rachel Sterling, PsyD, LMFT; Continuing Education Reviewer: D. Alvarez, LCSW",
    "financial_disclosures_and_mitigation": "All clinical presenters, instructional planners, and CE reviewers disclose zero financial relationships with commercial entities.",
    "commercial_support_statement": "This APA/ASWB/NBCC continuing education module was developed independently with zero commercial sponsorship.",
    "release_date": "2026-10-05",
    "expiration_date": "2029-10-05"
  },
  "evaluation_required_before_certificate": true,
  "post_evaluation": {
    "evaluation_required_before_certificate": true,
    "questions": [
      {
        "category": "objective_achievement",
        "question": "Rate the extent to which this continuing education activity achieved each stated learning objective."
      },
      {
        "category": "commercial_bias",
        "question": "Was this clinical continuing education activity balanced, evidence-based, and free of commercial bias?"
      }
    ]
  }
};
