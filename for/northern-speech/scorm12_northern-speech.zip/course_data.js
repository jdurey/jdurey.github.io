window.COURSE_DATA = {
  "course_id": "NSS_DYSPHAGIA_E353",
  "org_name": "Northern Speech Services",
  "title": "Northern Speech Services - Cardiopulmonary Dysphagia & Beyond-A-Score Diagnostics CEU (Demo)",
  "credit_badge": "2.0 Contact Hours (0.20 ASHA CEUs) · Medical SLP & Assessment SCORM 1.2",
  "source_digest": "Compiled from ASHA Dysphagia Practice Portal guidelines, respiratory-swallow phase coordination physiology, and psychometric diagnostic accuracy standards (sensitivity/specificity vs percentile cutoffs), modeled on Northern Speech Services' catalog ('Medical Speech Pathology Essentials for Dysphagia Practice' & 'e353: Moving Beyond A Score').",
  "ceu_profile": "accme_ancc_acpe",
  "mastery_score": 80,
  "pass_score": 80,
  "no_answer_leak_on_fail": true,
  "reveal_answers_on_fail": false,
  "objectives": [
    {
      "id": "OBJ_1",
      "text": "Diagnose respiratory-swallow phase discoordination (inspiratory post-swallow patterns) in COPD and post-extubation dysphagia on instrumental VFSS/FEES."
    },
    {
      "id": "OBJ_2",
      "text": "Differentiate oropharyngeal biomechanical impairment from pharyngoesophageal motility and gastroesophageal reflux contributors prior to therapy selection."
    },
    {
      "id": "OBJ_3",
      "text": "Evaluate standardized speech-language test sensitivity, specificity, likelihood ratios, and dynamic assessment evidence rather than relying on arbitrary SD cutoffs."
    }
  ],
  "sections": [
    {
      "title": "1. Respiratory-Swallow Coordination in COPD, Airway Defense & Esophageal-Pharyngeal Interactions",
      "html": "<p>Healthy adults predominantly pause respiration during the expiratory phase, execute pharyngeal swallow apnea, and resume expiration post-swallow (Expiratory-Swallow-Expiratory), helping clear laryngeal vestibule residue. Adults with moderate-to-severe COPD, tachypnea, or recent extubation frequently shift to Swallowing-Followed-by-Inspiration, creating negative subglottic pressure that draws pyriform or laryngeal vestibule residue into the airway silently.</p><p>Bedside cough absence never rules out silent aspiration; instrumental VFSS (including an esophageal sweep in upright/functional views) or FEES is essential to distinguish upper esophageal sphincter / esophageal stasis and laryngopharyngeal reflux (often empirically over-treated with omeprazole (Prilosec) without motility workup) from primary pharyngeal propulsion deficits.</p>"
    },
    {
      "title": "2. Moving Beyond A Score (e353): Diagnostic Sensitivity, Specificity & Convergent Functional Evidence",
      "html": "<p>Applying uniform -1.5 SD or -2.0 SD omnibus percentile cutoffs to determine speech-language eligibility misclassifies children when a test&#x27;s normative sample excludes disorder subgroups or exhibits poor diagnostic sensitivity (&lt; 80 percent). Under ASHA evidence-based assessment principles, clinicians select empirically derived cut scores maximizing sensitivity and specificity (with positive likelihood ratios &gt;= 3.0 and negative likelihood ratios &lt;= 0.30) and triangulate standardized results with language-sample analysis and dynamic assessment modifiability.</p>"
    }
  ],
  "quiz": [
    {
      "objective_id": "OBJ_1",
      "question": "Why does an adult with acute-on-chronic COPD hyperinflation exhibit elevated aspiration risk during sequential thin-liquid cup sips despite intact vocal fold adduction?",
      "options": [
        "Tachypnea and shortened swallow apnea drive post-swallow inspiration, generating negative airway pressure when pharyngeal residue remains near the laryngeal vestibule",
        "Healthy adults always inhale immediately after swallowing to oxygenate the glottis",
        "Bedside absence of overt coughing proves thin liquids are clearing without laryngeal penetration",
        "Thickening all liquids to extremely thick (IDDSI Level 4) automatically eliminates COPD work-of-breathing fatigue and dehydration risk"
      ],
      "explanations": [
        "Swallow-inspiration phase coupling pulls residual bolus material into the airway during post-swallow inhalation.",
        "Normative respiratory-swallow patterning is expiratory-swallow-expiratory, which facilitates airway clearance.",
        "Silent aspiration occurs without reflexive cough, requiring instrumental VFSS or FEES visualization.",
        "Overly thickened liquids can increase pharyngeal residue, oral effort, respiratory fatigue, and dehydration in COPD patients."
      ],
      "correct": 1,
      "overall": "Disrupted expiratory-swallow-expiratory timing in COPD creates post-swallow inspiratory suction across residual bolus material."
    },
    {
      "objective_id": "OBJ_2",
      "question": "During VFSS, a patient reports a 'food sticking at the sternal notch' sensation, displays normal hyolaryngeal excursion and pharyngeal stripping, but exhibits retrograde bolus flow from the mid-esophagus back toward the cricopharyngeus despite daily omeprazole (Prilosec). What is the SLP's appropriate action?",
      "options": [
        "Prescribe intensive Masako tongue-hold exercises for four weeks without medical referral",
        "Document intact oropharyngeal biomechanics alongside observed esophageal stasis/retrograde flow and refer to gastroenterology for esophageal motility evaluation",
        "Adjust the patient's omeprazole (Prilosec) dosage independently to twice daily",
        "Diagnose a definitive esophageal adenocarcinoma from the lateral fluoroscopy screen"
      ],
      "explanations": [
        "Pharyngeal strengthening exercises do not treat intra-esophageal stasis or motility disorders and waste clinical resources.",
        "Patients often localize esophageal retention to the neck/suprasternal region; SLPs document esophageal sweep observations and refer to GI.",
        "Medication prescribing and dosage changes fall outside SLP scope of practice.",
        "Medical diagnosis of esophageal pathology belongs to the physician/gastroenterologist; the SLP reports physiological observations and refers."
      ],
      "correct": 2,
      "overall": "Visualizing esophageal retrograde flow with intact pharyngeal mechanics warrants GI referral rather than unindicated pharyngeal exercises."
    },
    {
      "objective_id": "OBJ_3",
      "question": "A school-based SLP administers a standardized language battery whose manual documents 62 percent sensitivity and 91 percent specificity at -1.5 SD, and a bilingual 7-year-old scores -1.2 SD while demonstrating significant narrative microstructure breakdowns and high dynamic-assessment scaffolding needs. How should the SLP interpret these data?",
      "options": [
        "Deny services automatically because the composite standard score is above the district's -1.5 SD cutoff",
        "Recognize that 62 percent sensitivity misses 38 percent of true language disorders, and weight convergent narrative, classroom impact, and dynamic-assessment evidence",
        "Re-administer the exact same norm-referenced subtests the next morning until the score drops below -1.5 SD",
        "Average four unrelated articulation and fluency percentiles into the language composite"
      ],
      "explanations": [
        "Rigidly applying an insensitive omnibus cutoff violates IDEA multi-source evaluation mandates and misses true impairment.",
        "Low sensitivity (< 80 percent) produces high false-negative rates; triangulating dynamic assessment and functional language sampling prevents under-identification.",
        "Immediate re-testing violates test-retest validity and introduces practice effects.",
        "Averaging distinct construct domains is psychometrically invalid."
      ],
      "correct": 2,
      "overall": "Moving beyond a single composite score requires evaluating test sensitivity/specificity alongside functional language and dynamic assessment."
    },
    {
      "objective_id": "OBJ_3",
      "question": "When appraising a diagnostic speech-language assessment manual, which psychometric benchmark indicates informative diagnostic accuracy for ruling in and ruling out a disorder?",
      "options": [
        "High internal consistency (Cronbach reliability = 0.90) alone, with zero reported sensitivity or specificity data",
        "Sensitivity and specificity both >= 80 percent at the empirically derived cut score, yielding LR+ >= 3.0 and LR- <= 0.30",
        "Normative sample consisting exclusively of children with no speech or language disorders and zero clinical validation group",
        "Reliance on age-equivalent scores to quantify standard error of measurement"
      ],
      "explanations": [
        "Reliability does not establish diagnostic classification accuracy between impaired and typical groups.",
        "Plante & Vance / ASHA diagnostic benchmarks support >= 80 percent sensitivity/specificity and informative positive/negative likelihood ratios.",
        "Excluding clinical disorder groups from normative samples without a separate clinical sensitivity study cannot establish diagnostic cutoffs.",
        "Age-equivalent scores are ordinal median estimates with unequal intervals and never measure diagnostic accuracy."
      ],
      "correct": 2,
      "overall": "Diagnostic validity depends on empirically tested sensitivity/specificity (>= 80 percent) and likelihood ratios, never age equivalents or reliability alone."
    }
  ],
  "front_matter_rendered_before_content": true,
  "front_matter": {
    "faculty_credentials": "Course Author: Hannah Mercer, MS, CCC-SLP, BCS-S; ASHA CE Reviewer: K. Lin, PhD, CCC-SLP",
    "financial_disclosures_and_mitigation": "Author receives course authorship royalties; zero relevant financial or non-financial relationships exist with medical device or pharmaceutical manufacturers.",
    "commercial_support_statement": "This ASHA continuing education module received zero commercial support or device sponsorship.",
    "release_date": "2026-10-10",
    "expiration_date": "2029-10-10"
  },
  "evaluation_required_before_certificate": true,
  "post_evaluation": {
    "evaluation_required_before_certificate": true,
    "questions": [
      {
        "category": "objective_achievement",
        "question": "Rate the extent to which this continuing education activity achieved each stated learning objective."
      },
      {
        "category": "commercial_bias",
        "question": "Was this clinical continuing education activity balanced, evidence-based, and free of commercial bias?"
      }
    ]
  }
};
