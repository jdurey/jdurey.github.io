window.COURSE_DATA = {
  "course_id": "NACLE_CLE_EDISC_TECH",
  "org_name": "National Academy of Continuing Legal Education",
  "title": "National Academy of Continuing Legal Education - E-Discovery FRE 502(d) & ABA Tech Ethics CLE (Demo)",
  "credit_badge": "1.0 CLE Credit (Ethics & Technology) · Multi-State Self-Study CLE SCORM 1.2",
  "source_digest": "Compiled from FRCP Rules 26(b)(1), 26(f) & 37(e), Federal Rule of Evidence 502(d), ABA Model Rules 1.1 (Comment 8), 1.6(c), 3.3 & 5.3, and ABA Formal Opinion 512, modeled on National Academy of Continuing Legal Education's catalog ('3 Ways to Create More Favorable Case Outcomes with E-Discovery Principles' & 'ABA Ethical Rule Amendments: Changing Attorneys' Relationship with Technology').",
  "ceu_profile": "cle_pdh",
  "mastery_score": 75,
  "pass_score": 75,
  "no_answer_leak_on_fail": true,
  "reveal_answers_on_fail": false,
  "objectives": [
    {
      "id": "OBJ_1",
      "text": "Draft Federal Rule of Evidence 502(d) non-waiver orders and proportional FRCP Rule 26(f) ESI protocols to protect privilege during high-volume productions."
    },
    {
      "id": "OBJ_2",
      "text": "Apply FRCP Rule 37(e) preservation duties and curative versus intent-to-deprive spoliation standards to ephemeral messaging and cloud repositories."
    },
    {
      "id": "OBJ_3",
      "text": "Implement ABA Model Rules 1.1 (Comment 8), 1.6(c), 3.3, and 5.3 supervisory controls when using generative AI or cloud legal-tech vendors."
    }
  ],
  "sections": [
    {
      "title": "1. Strategic E-Discovery: FRCP Rule 26(f) Proportionality, FRE 502(d) Clawback Orders & Rule 37(e) ESI Spoliation",
      "html": "<p>Proactive e-discovery governance shapes litigation leverage at the FRCP Rule 26(f) conference. Unlike a mere party clawback agreement under FRE 502(e) or reliance on post-hoc &#x27;reasonable steps&#x27; proof under FRE 502(b), obtaining a court-entered Federal Rule of Evidence 502(d) order ensures that production of privileged ESI does not waive privilege in that federal proceeding or in any other federal or state proceeding, even without proving pre-production review perfection.</p><p>Under amended FRCP Rule 37(e), when ESI that should have been preserved in anticipation of litigation is lost because a party failed to take reasonable steps (such as failing to suspend 30-day Slack/Teams auto-deletion), the court orders measures no greater than necessary to cure prejudice under Rule 37(e)(1), reserving severe adverse-inference instructions or default/dismissal under Rule 37(e)(2) strictly for findings that the party acted with the intent to deprive another party of the information&#x27;s use in litigation.</p>"
    },
    {
      "title": "2. ABA Technology Ethics Amendments & Formal Opinion 512: Competence, Confidentiality & Candor",
      "html": "<p>ABA Model Rule 1.1 Comment 8 obligates lawyers to maintain abreast of benefits and risks associated with relevant technology, while Model Rule 1.6(c) requires reasonable efforts to prevent inadvertent or unauthorized disclosure of client information. Under ABA Formal Opinion 512, uploading confidential client facts into a public self-learning AI tool that retains prompts for model training without informed client consent breaches Rule 1.6.</p><p>Further, Model Rule 5.3 requires nonlawyer vendor due diligence (SOC 2 / zero-retention API terms) and active lawyer supervision, and Model Rule 3.3(a)(1) imposes an unwaivable duty of candor to verify every citation and evidentiary quote against primary reporters before filing.</p>"
    }
  ],
  "quiz": [
    {
      "objective_id": "OBJ_1",
      "question": "Litigation counsel faces a compressed rolling production of 450,000 Slack messages and emails in federal court. Why should counsel move for a court-entered FRE 502(d) order rather than relying solely on FRE 502(b) or an unentered FRE 502(e) stipulation?",
      "options": [
        "A court-entered FRE 502(d) order prevents privilege waiver in both the pending federal action and any other federal or state proceeding without litigating FRE 502(b) 'reasonable steps' adequacy",
        "An unentered FRE 502(e) party letter automatically binds third-party subpoenas in subsequent state-court class actions",
        "FRE 502(d) allows counsel to intentionally use privileged documents offensively as a sword while shielding related communications",
        "FRE 502(b) eliminates any obligation to rectify an inadvertent disclosure once counsel discovers it"
      ],
      "explanations": [
        "FRE 502(d) provides nationwide federal and state non-waiver protection against third parties without costly post-production 'reasonable steps' motion practice.",
        "Under FRE 502(e), a bilateral party agreement binds only the signatories unless incorporated into a court order under FRE 502(d).",
        "Selective offensive use of privileged material triggers subject-matter waiver principles; FRE 502(d) protects against unintended disclosure waiver, not selective sword-and-shield abuse.",
        "FRE 502(b)(3) expressly requires prompt reasonable steps to rectify the error once known."
      ],
      "correct": 1,
      "overall": "A court-entered FRE 502(d) order is the gold-standard safeguard against privilege waiver across both current and subsequent federal/state actions."
    },
    {
      "objective_id": "OBJ_2",
      "question": "After receiving a credible pre-suit demand letter, a corporate defendant issues a written email hold but negligently forgets to pause a 14-day auto-purge setting on an executive messaging channel, without any intent to hide evidence. Under FRCP Rule 37(e), which sanction is permissible if prejudice is shown?",
      "options": [
        "Mandatory jury instruction presuming the lost messages were unfavorable to the defendant under Rule 37(e)(2)",
        "Targeted curative measures no greater than necessary to cure the prejudice under Rule 37(e)(1), excluding adverse-inference instructions or dismissal",
        "Automatic default judgment on liability regardless of alternative evidence",
        "Criminal contempt referral under Rule 11"
      ],
      "explanations": [
        "Rule 37(e)(2) restricts adverse-inference jury instructions, dismissal, and default judgment strictly to cases where the party acted with 'intent to deprive'.",
        "Negligent or even grossly negligent failure to suspend auto-delete without intent to deprive is governed by Rule 37(e)(1) proportional curative remedies.",
        "Default judgment requires an affirmative finding of intent to deprive under Rule 37(e)(2)(C).",
        "Rule 11 governs signed pleadings/motions, not ESI preservation."
      ],
      "correct": 2,
      "overall": "FRCP Rule 37(e)(2) reserves adverse-inference instructions and terminating sanctions exclusively for intentional deprivation of ESI."
    },
    {
      "objective_id": "OBJ_3",
      "question": "An associate pastes an unredacted M&A due-diligence memo into a consumer generative AI web tool whose terms permit human contractor review and model training, then files the AI-drafted brief without cite-checking two fabricated appellate holdings. Which ABA Model Rules were violated?",
      "options": [
        "Only Model Rule 1.5 on fee reasonableness, provided the associate did not bill for the prompt time",
        "Model Rules 1.1 (technological competence), 1.6(c) (confidentiality), and 3.3(a)(1) (candor toward the tribunal)",
        "Zero ethical rules because software vendors bear sole strict liability for citation accuracy",
        "Model Rule 4.2 on communicating with represented parties"
      ],
      "explanations": [
        "While ABA Formal Opinion 512 also addresses billing transparency under Rule 1.5, the primary breaches here are competence, confidentiality, and candor.",
        "Exposing client confidences to a training-enabled tool violates Rules 1.1 & 1.6(c), and filing unverified fabricated case citations violates Rule 3.3(a)(1).",
        "Signing and filing counsel hold non-delegable duties under FRCP Rule 11 and Model Rule 3.3.",
        "Rule 4.2 governs ex parte contact with represented persons, not AI vendor confidentiality or brief verification."
      ],
      "correct": 2,
      "overall": "ABA Formal Opinion 512 enforces competence (Rule 1.1), client data confidentiality (Rule 1.6), vendor oversight (Rule 5.3), and citation verification (Rule 3.3)."
    },
    {
      "objective_id": "OBJ_3",
      "question": "Under ABA Model Rule 5.3 and Formal Opinion 512, which firm governance control is required before deploying a cloud e-discovery or legal-AI platform across client matters?",
      "options": [
        "Verify zero-training contractual data isolation, encryption/access controls, and mandatory lawyer primary-source verification prior to any external filing",
        "Allow individual paralegals to adopt free browser extensions ad hoc without IT or ethics review",
        "Delegate final brief sign-off to the cloud vendor's automated confidence score",
        "Disclose opposing counsel's privileged clawback documents into public prompt libraries"
      ],
      "explanations": [
        "Rule 5.3 requires vetting third-party technology terms (confidentiality, zero model-training retention, security) and enforcing lawyer review of outputs.",
        "Unvetted shadow-IT extensions create direct Rule 1.6 confidentiality breaches.",
        "Independent professional judgment and Rule 3.3 verification can never be delegated to software confidence scores.",
        "Uploading clawed-back or confidential discovery materials to public systems violates protective orders and ethics rules."
      ],
      "correct": 1,
      "overall": "Supervising partners must enforce enterprise zero-retention terms under Rule 5.3 and human primary-source verification under Rule 3.3."
    }
  ],
  "verified_seat_minutes": 60.0,
  "tracks_session_time": true,
  "tracks_lesson_location": true,
  "anti_skip_gating": true,
  "randomize_options_on_retry": true,
  "attention_checkpoints": [
    {
      "minute_mark": 18,
      "prompt": "CLE Seat-Time Verification 1 (18:00): Confirm active attorney participation in Module 1."
    },
    {
      "minute_mark": 36,
      "prompt": "CLE Seat-Time Verification 2 (36:00): Confirm active attorney participation in Module 2."
    },
    {
      "minute_mark": 54,
      "prompt": "CLE Seat-Time Verification 3 (54:00): Confirm active attorney participation prior to Post-Test."
    }
  ]
};
